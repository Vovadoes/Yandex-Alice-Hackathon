from models.race.elf import Elf
from models.race.halfling import Halfling
from models.race.dwarf import Dwarf

race = [Elf(), Halfling(), Dwarf()]
