from models.сurses.UnbearablyVileCurseLoseYourRandomStuff import \
    UnbearablyVileCurseLoseYourRandomStuff
from models.сurses.YourWeaponWasStolenWhatSlobYouAre import YourWeaponWasStolenWhatSlobYouAre
from models.сurses.Lose2LevelsSoThatItWontBeHabitToPickUpBirdsInTheDungeonsFromNowOn import \
    Lose2LevelsSoThatItWontBeHabitToPickUpBirdsInTheDungeonsFromNowOn
from models.сurses.LoseTheLevel import LoseTheLevel
from models.сurses.LoseTheArmorYoureWearing import LoseTheArmorYoureWearing
from models.сurses.LoseTheShoesYoureWearing import LoseTheShoesYoureWearing
from models.сurses.LoseTheFirebrandYoureWearing import LoseTheFirebrandYoureWearing

curses = [Lose2LevelsSoThatItWontBeHabitToPickUpBirdsInTheDungeonsFromNowOn(),
          LoseTheArmorYoureWearing(), LoseTheFirebrandYoureWearing(), LoseTheLevel(),
          LoseTheShoesYoureWearing(), UnbearablyVileCurseLoseYourRandomStuff(),
          YourWeaponWasStolenWhatSlobYouAre()]
