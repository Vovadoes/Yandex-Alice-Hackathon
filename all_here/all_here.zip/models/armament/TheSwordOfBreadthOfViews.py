from .ArmamentBase import ArmamentBase


class TheSwordOfBreadthOfViews(ArmamentBase):
    def __init__(self):
        super(TheSwordOfBreadthOfViews, self).__init__(3, 'Меч широты взглядов', 400, 1, 1)

    def use_armament(self, req, hero):  # надеваем достпехи/оружие
        # в отдельную переменную доб бонус
        pass
