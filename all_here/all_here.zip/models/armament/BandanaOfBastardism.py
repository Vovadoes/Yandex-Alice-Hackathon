from .ArmamentBase import ArmamentBase


class BandanaOfBastardism(ArmamentBase):
    def __init__(self):
        super(BandanaOfBastardism, self).__init__(3, 'Бондана сволочизма', 400, 2)

    def use_armament(self, req, hero):  # надеваем достпехи/оружие
        # в отдельную переменную доб бонус
        pass
