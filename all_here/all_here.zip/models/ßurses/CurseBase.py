class CurseBase: # проклятье
    def __init__(self, title):
        self.title = title

    def use_bad_things(self, req, hero):  # проклятье на нас
        pass