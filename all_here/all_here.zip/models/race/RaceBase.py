class RaceBase:  # раса
    def __init__(self, what, title, *args, **kwargs):
        self.title = title
        self.what = what
