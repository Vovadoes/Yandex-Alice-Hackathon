from .RaceBase import RaceBase


class Dwarf(RaceBase):
    def __init__(self):
        super().__init__(3, 'Дварфы очень сильные создания! +2 к силе персонажа!')
